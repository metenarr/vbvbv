//Класс является окном для входа уже зарегестрированых пользователей сделан 02 04 Назарычевым
package com.example.onesessia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import com.example.onesessia.R;
import com.example.onesessia.passwordforgot;
import com.example.onesessia.signup;

public class loginin extends AppCompatActivity {

    private AppCompatButton log;
    private String emailText;
    private String passText;

    private EditText email;
    private EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginin);

        log = findViewById(R.id.button2);
        passText = "";
        emailText = "";

        email = findViewById(R.id.editTextTextEmailAddress2);
        pass = findViewById(R.id.editTextTextPassword3);

        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                emailText = email.getText().toString();
                passText = pass.getText().toString();
                Validation(emailText, passText);
            }

            private void Validation(String emailText, String passText) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                emailText = email.getText().toString();
                passText = pass.getText().toString();
                Validation(emailText, passText);
            }

            private void Validation(String emailText, String passText) {
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }


    public void Sign_in(View v) {
        Intent intent = new Intent(this, signup.class);
        startActivity(intent);
    }
    public void ForgotPassword(View v) {
        Intent intent = new Intent(this, passwordforgot.class);
        startActivity(intent);
    }

}