//Сделала Швецова Мария Сергеенва 3ИСиП-21-3к
//01.04.2023



package com.example.onesessia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

public class activity_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(activity_main.this, bord1.class);
                startActivity(intent);
            }
        }, 3000);
    }
    //Тут мы устанавливаем таймер на 3 секунды с помощью Handler
    public void onClick(View v){
            Intent intent = new Intent(this, bord1.class);
            startActivity(intent);
    }
}
//По истечении этих 3 секунд происходит переход на другой экран с названием bord1