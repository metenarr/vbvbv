package com.example.onesessia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

public class signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }
    public void SignUp(View v) {
        Intent intent = new Intent(this, signup.class);
        startActivity(intent);
    }
    public void Sign_Up(View v) {
        Intent intent = new Intent(this, home.class);
        startActivity(intent);
    }
}
//Класс является окном для регистрации сделан 02 04 Назарычевым

